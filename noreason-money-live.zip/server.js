require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

const transactions = new Map();

function formatUAH(n) {
  return new Intl.NumberFormat("uk-UA", {
    style: "currency",
    currency: "UAH",
    maximumFractionDigits: 0
  }).format(n);
}

function commissionRate(amount) {
  const tiers = [
    [25000, 0.01],
    [10000, 0.05],
    [5000, 0.10],
    [1000, 0.15],
    [0, 0.20]
  ];
  return tiers.find(([min]) => amount >= min)[1];
}

async function telegram(text) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.warn("Telegram is not configured: set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID.");
    return false;
  }

  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      disable_web_page_preview: true
    })
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Telegram API ${response.status}: ${body}`);
  }
  return true;
}

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    service: "noreason.money",
    telegramConfigured: Boolean(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID),
    paymentProviderConfigured: Boolean(process.env.PAYMENT_CHECKOUT_URL)
  });
});

/*
 * Captures the chat_id after the owner sends /start to the bot.
 * Run:
 *   GET /api/telegram/updates
 *
 * The endpoint does not expose the bot token. It only returns the
 * numeric chat_id found in Telegram updates.
 */
app.get("/api/telegram/updates", async (_req, res) => {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return res.status(503).json({ ok: false, error: "TELEGRAM_BOT_TOKEN is not configured" });

  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/getUpdates?limit=20&timeout=1`);
    const data = await r.json();
    if (!data.ok) return res.status(502).json({ ok: false, error: "Telegram getUpdates failed" });

    const chats = [];
    for (const u of data.result || []) {
      const chat = u.message?.chat || u.my_chat_member?.chat;
      if (chat) chats.push({
        chat_id: chat.id,
        type: chat.type,
        title: chat.title || null,
        username: chat.username || null,
        first_name: chat.first_name || null
      });
    }

    res.json({ ok: true, chats });
  } catch (e) {
    res.status(502).json({ ok: false, error: "Telegram connection failed" });
  }
});

app.post("/api/demo-payment", async (req, res) => {
  const amount = Number(req.body.amount);
  const recipientName = String(req.body.recipientName || "").trim();
  const recipientContact = String(req.body.recipientContact || "").trim();

  if (!Number.isFinite(amount) || amount < 1) {
    return res.status(400).json({ ok: false, error: "Некоректна сума." });
  }

  const rate = commissionRate(amount);
  const fee = Math.round(amount * rate);
  const payout = amount - fee;
  const id = "NR-" + crypto.randomBytes(4).toString("hex").toUpperCase();

  const tx = {
    id,
    amount,
    fee,
    payout,
    rate,
    recipientName,
    recipientContact,
    status: "DEMO_CREATED",
    createdAt: new Date().toISOString()
  };

  transactions.set(id, tx);

  const msg = [
    "NEW PAYMENT / DEMO",
    `Transaction #${id}`,
    `Amount ${formatUAH(amount)}`,
    `Commission ${formatUAH(fee)} (${Math.round(rate * 100)}%)`,
    `Recipient payout ${formatUAH(payout)}`,
    `Status DEMO_CREATED`,
    recipientName ? `Recipient ${recipientName}` : null,
    recipientContact ? `Contact ${recipientContact}` : null,
    `Created ${tx.createdAt}`
  ].filter(Boolean).join("\n");

  try {
    await telegram(msg);
  } catch (e) {
    console.error(e.message);
  }

  res.json({ ok: true, transaction: tx });
});

/*
 * Production payment-provider webhook placeholder.
 * Implement the provider's signature verification here before going live.
 */
app.post("/api/payment/webhook", (req, res) => {
  res.status(501).json({
    ok: false,
    error: "Payment provider webhook is not configured yet.",
    message: "Set up a merchant account and implement its signed webhook before accepting real payments."
  });
});

app.get("/api/track/:id", (req, res) => {
  const tx = transactions.get(req.params.id);
  if (!tx) return res.status(404).json({ ok: false, error: "Транзакцію не знайдено." });
  res.json({
    ok: true,
    id: tx.id,
    status: tx.status,
    amount: tx.amount,
    fee: tx.fee,
    payout: tx.payout,
    createdAt: tx.createdAt
  });
});

app.listen(PORT, () => {
  console.log(`NO REASON running on http://localhost:${PORT}`);
});
