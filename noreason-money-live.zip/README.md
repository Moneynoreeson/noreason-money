# NO REASON — live-ready package

## Що вже працює

- преміальний адаптивний frontend;
- калькулятор комісії;
- створення транзакції через backend у demo-режимі;
- Telegram Bot API інтеграція на сервері;
- сторінка/endpoint для перевірки Telegram `chat_id`;
- tracking endpoint;
- структура для signed payment-provider webhook;
- секрети не знаходяться у frontend.

## Запуск

Потрібен Node.js 18+.

```bash
npm install
copy .env.example .env
npm start
```

Відкрий:

`http://localhost:3000`

## Telegram

1. У @BotFather відклич старий токен і створи новий.
2. Встав новий токен у `.env`:
   `TELEGRAM_BOT_TOKEN=...`
3. Напиши своєму боту `/start`.
4. Відкрий:
   `http://localhost:3000/api/telegram/updates`
5. Скопіюй числовий `chat_id` у `.env`:
   `TELEGRAM_CHAT_ID=...`
6. Перезапусти сервер.

Токен бота не можна публікувати в HTML, GitHub або браузерному JavaScript.

## Важливо про реальні гроші

Ця збірка не прикидається платіжним провайдером. Для реального приймання карткових платежів потрібен merchant-акаунт у платіжного провайдера та його API/webhook.

Правильний production flow:

Користувач → hosted checkout провайдера → payment webhook → backend → транзакція → Telegram → ручна виплата отримувачу.

Не приймай номер картки/CVV/PIN через звичайну HTML-форму і не надсилай ці дані в Telegram.

Перед запуском реальних платежів потрібно реалізувати саме webhook/signature verification конкретного провайдера та перевірити юридичні/merchant-вимоги.
